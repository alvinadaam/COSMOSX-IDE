// Enhanced Live Preview System - Real-time CosmosUI Integration
// Advanced preview with real-time updates, better error handling, and enhanced UI

import { CosmosUI } from '../cosmosx-engine/core/CosmosUI/index.js';
import { CosmosEngine } from '../cosmosx-engine/core/CosmosEngine/engine.js';
import { parseCosLang } from '../cosmosx-engine/core/CosmosEngine/parser.js';
import { logger } from '../cosmosx-engine/logger.js';
import { getImageAssetStyles, getAudioAssetAttrs, getVideoAssetStyles } from '../cosmosx-engine/core/CosmosUI/components/assetStyleUtils.js';

export class LivePreview {
    constructor() {
        this.engine = null;
        this.ui = null;
        this.isActive = false;
        this.updateTimeout = null;
        this.lastContentHash = null;
        this.previewState = {
            isPlaying: false,
            currentScene: null,
            storyProgress: 0,
            totalChoices: 0,
            choicesMade: 0
        };
        this.history = [];
        this.maxHistorySize = 50;
    }

    // Initialize the preview system
    init() {
        logger.info('🎮 Enhanced Live Preview System initializing...');
        this.setupPreviewContainer();
        this.setupPreviewEvents();
        this.setupRealTimeUpdates();
        this.isActive = true;
        logger.info('✅ Enhanced Live Preview System ready');
    }

    // Setup the preview container in the preview tab
    setupPreviewContainer() {
        const previewFrame = document.getElementById('preview-frame');
        if (!previewFrame) {
            console.error('Preview frame not found');
            return;
        }

        console.log('Setting up preview container...');

        // Clear existing content
        previewFrame.innerHTML = '';

        // Create enhanced preview structure
        const previewContainer = document.createElement('div');
        previewContainer.className = 'live-preview-container';
        previewContainer.innerHTML = `
            <div class="preview-header">
                <div class="preview-title">
                    <h3><i class="fas fa-play"></i> Live Preview</h3>
                    <div class="preview-status">
                        <span id="preview-status" class="status-indicator">Ready</span>
                        <span id="preview-progress" class="progress-indicator">0%</span>
                    </div>
                </div>
                <div class="preview-controls">
                    <button id="preview-play" class="btn btn-sm btn-primary">
                        <i class="fas fa-play"></i> Play
                    </button>
                    <button id="preview-pause" class="btn btn-sm" style="display:none;">
                        <i class="fas fa-pause"></i> Pause
                    </button>
                    <button id="preview-restart" class="btn btn-sm">
                        <i class="fas fa-redo"></i> Restart
                    </button>
                    <button id="preview-step" class="btn btn-sm">
                        <i class="fas fa-forward"></i> Step
                    </button>
                    <button id="preview-fullscreen" class="btn btn-sm">
                        <i class="fas fa-expand"></i> Fullscreen
                    </button>
                </div>
            </div>
            <div class="preview-content">
                <div class="preview-main">
                    <div id="preview-story" class="preview-story"></div>
                    <div id="preview-choices" class="preview-choices"></div>
                </div>
                <div class="preview-sidebar">
                    <div class="preview-panels">
                        <div id="preview-stats" class="preview-panel">
                            <h4><i class="fas fa-chart-line"></i> Stats</h4>
                            <div class="panel-content"></div>
                        </div>
                        <div id="preview-inventory" class="preview-panel">
                            <h4><i class="fas fa-briefcase"></i> Inventory</h4>
                            <div class="panel-content"></div>
                        </div>
                        <div id="preview-variables" class="preview-panel">
                            <h4><i class="fas fa-code-branch"></i> Variables</h4>
                            <div class="panel-content"></div>
                        </div>
                        <div id="preview-log" class="preview-panel">
                            <h4><i class="fas fa-list-alt"></i> Log</h4>
                            <div class="panel-content"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="preview-footer">
                <div class="preview-info">
                    <span id="preview-scene">Scene: None</span>
                    <span id="preview-position">Position: 0</span>
                </div>
                <div class="preview-actions">
                    <button id="preview-history-back" class="btn btn-sm" disabled>
                        <i class="fas fa-arrow-left"></i> Back
                    </button>
                    <button id="preview-history-forward" class="btn btn-sm" disabled>
                        <i class="fas fa-arrow-right"></i> Forward
                    </button>
                </div>
            </div>
        `;

        previewFrame.appendChild(previewContainer);

        // Setup event listeners
        this.setupPreviewEvents();
    }

    // Setup preview event listeners
    setupPreviewEvents() {
        const playBtn = document.getElementById('preview-play');
        const pauseBtn = document.getElementById('preview-pause');
        const restartBtn = document.getElementById('preview-restart');
        const stepBtn = document.getElementById('preview-step');
        const fullscreenBtn = document.getElementById('preview-fullscreen');
        const historyBackBtn = document.getElementById('preview-history-back');
        const historyForwardBtn = document.getElementById('preview-history-forward');

        if (playBtn) {
            playBtn.addEventListener('click', () => this.startPreview());
        }

        if (pauseBtn) {
            pauseBtn.addEventListener('click', () => this.pausePreview());
        }

        if (restartBtn) {
            restartBtn.addEventListener('click', () => this.restartPreview());
        }

        if (stepBtn) {
            stepBtn.addEventListener('click', () => this.stepPreview());
        }

        if (fullscreenBtn) {
            fullscreenBtn.addEventListener('click', () => this.toggleFullscreen());
        }

        if (historyBackBtn) {
            historyBackBtn.addEventListener('click', () => this.goBackInHistory());
        }

        if (historyForwardBtn) {
            historyForwardBtn.addEventListener('click', () => this.goForwardInHistory());
        }
    }

    // Setup real-time updates from editor
    setupRealTimeUpdates() {
        // Listen for editor content changes
        if (window.ide && window.ide.editorManager && window.ide.editorManager.editor) {
            window.ide.editorManager.editor.onDidChangeModelContent(() => {
                this.handleEditorContentChange();
            });
        }

        // Listen for tab switches
        const previewTab = document.querySelector('[data-tab="preview"]');
        if (previewTab) {
            previewTab.addEventListener('click', () => {
                setTimeout(() => this.updatePreviewFromEditor(), 100);
            });
        }
    }

    // Handle editor content changes
    handleEditorContentChange() {
        if (!this.isActive) return;

        // Debounce updates to prevent excessive re-rendering
        if (this.updateTimeout) {
            clearTimeout(this.updateTimeout);
        }

        this.updateTimeout = setTimeout(() => {
            this.updatePreviewFromEditor();
        }, 500); // 500ms debounce for real-time updates
    }

    // Update preview from current editor content
    updatePreviewFromEditor() {
        if (!window.ide || !window.ide.editorManager || !window.ide.editorManager.editor) return;

        const content = window.ide.editorManager.getValue();
        const contentHash = this.hashContent(content);

        // Only update if content actually changed
        if (contentHash !== this.lastContentHash) {
            this.lastContentHash = contentHash;
            this.updatePreview(content);
        }
    }

    // Simple hash function for content comparison
    hashContent(content) {
        let hash = 0;
        for (let i = 0; i < content.length; i++) {
            const char = content.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return hash;
    }

    // Update preview with new story content
    updatePreview(coslangText) {
        if (!this.isActive) return;

        try {
            console.log('🔄 Updating live preview...');
            
            // Parse the story
            const ast = parseCosLang(coslangText);
            
            // Debug: Log AST structure
            console.log('AST structure:', {
                meta: ast.meta,
                scenes: Object.keys(ast.scenes || {}),
                scenesCount: Object.keys(ast.scenes || {}).length
            });
            
            // Check if 'start' scene exists
            if (!ast.scenes || !ast.scenes.start) {
                console.error('❌ No "start" scene found in AST. Available scenes:', Object.keys(ast.scenes || {}));
                this.showPreviewError('No "start" scene found. Available scenes: ' + Object.keys(ast.scenes || {}).join(', '));
                this.updatePreviewStatus('Error: No start scene', 'error');
                return;
            }
            
            // Create new engine and UI
            this.engine = new CosmosEngine(ast);
            this.ui = new CosmosUI(this.engine);

            // Start the story
            this.engine.start('start', { reset: true });
            
            // Render the current state
            this.renderPreview();
            
            // Update status
            this.updatePreviewStatus('Ready', 'success');
            this.updatePreviewProgress();
            
            console.log('✅ Live preview updated successfully');
        } catch (error) {
            console.error('❌ Live preview update failed:', error);
            this.showPreviewError(error.message);
            this.updatePreviewStatus('Error: ' + error.message, 'error');
        }
    }

    // Render the current preview state
    renderPreview() {
        if (!this.ui) {
            console.warn('No UI available for rendering');
            return;
        }

        try {
            const renderable = this.ui.getRenderableStateAfterSetExecution();
            
            console.log('Renderable state:', renderable);

            // --- Main preview area ---
            const previewMain = document.querySelector('.preview-main');
            if (previewMain && window.ide && window.ide.scrollbarSystem && typeof window.ide.scrollbarSystem.applyScrollbarStyles === 'function') {
                window.ide.scrollbarSystem.applyScrollbarStyles(previewMain);
            }
            // Ensure robust flex layout for stacking
            if (previewMain) {
                previewMain.style.display = 'flex';
                previewMain.style.flexDirection = 'column';
                previewMain.style.alignItems = 'stretch';
                previewMain.style.justifyContent = 'flex-start';
                previewMain.style.minHeight = '400px';
                previewMain.style.position = 'relative';
            }
            // --- Render story text ---
            this.renderStoryText(renderable.text);
            // --- Render image and video below text ---
            let previewAssets = document.getElementById('preview-assets');
            if (!previewAssets && previewMain) {
                previewAssets = document.createElement('div');
                previewAssets.id = 'preview-assets';
                // Insert after story, before choices
                const storyEl = document.getElementById('preview-story');
                const choicesEl = document.getElementById('preview-choices');
                if (storyEl && choicesEl) {
                    previewMain.insertBefore(previewAssets, choicesEl);
                } else {
                    previewMain.appendChild(previewAssets);
                }
            }
            if (previewAssets) {
                previewAssets.innerHTML = '';
                previewAssets.style.background = 'none';
                previewAssets.style.border = 'none';
                previewAssets.style.padding = '0';
                previewAssets.style.margin = '0';
                previewAssets.style.maxWidth = '100%';
                previewAssets.style.boxShadow = 'none';
                previewAssets.style.display = 'flex';
                previewAssets.style.flexDirection = 'column';
                previewAssets.style.alignItems = 'center';
                previewAssets.style.gap = '0.7em';
                previewAssets.style.width = '100%';
                previewAssets.style.boxSizing = 'border-box';
                // Render image
                if (renderable.currentImage && renderable.currentImage.name) {
                    const img = document.createElement('img');
                    img.src = renderable.currentImage.resolvedPath;
                    // Use asset controls for styles/attributes
                    const { style, attrs } = getImageAssetStyles(renderable.currentImage.settings || {});
                    Object.assign(img.style, style);
                    Object.entries(attrs).forEach(([k, v]) => img.setAttribute(k, v));
                    previewAssets.appendChild(img);
                }
                // Render video below image (if present)
                if (renderable.currentVideo && renderable.currentVideo.name) {
                    const video = document.createElement('video');
                    video.src = renderable.currentVideo.resolvedPath;
                    // Use asset controls for styles/attributes
                    const { style, attrs } = getVideoAssetStyles(renderable.currentVideo.settings || {});
                    Object.assign(video.style, style);
                    Object.entries(attrs).forEach(([k, v]) => video.setAttribute(k, v));
                    video.style.margin = '1em auto 1em auto';
                    video.style.border = '2px solid var(--border-color, #444)';
                    video.style.borderRadius = '8px';
                    video.style.boxShadow = '0 2px 8px rgba(0,0,0,0.08)';
                    video.style.maxWidth = '100%';
                    video.style.display = 'block';
                    video.style.background = '#000';
                    previewAssets.appendChild(video);
                }
            }
            // --- Always render choices at the bottom ---
            const choicesEl = document.getElementById('preview-choices');
            if (choicesEl && previewMain) {
                choicesEl.style.marginTop = '1.5em';
                choicesEl.style.alignSelf = 'center';
                choicesEl.style.zIndex = 20;
                choicesEl.style.position = 'relative';
            }
            this.renderChoices(renderable.choices);

            // --- Play audio in the background (no visible player) ---
            if (renderable.currentAudio && renderable.currentAudio.resolvedPath) {
                // Remove any previous audio
                let existingAudio = document.getElementById('preview-audio-bg');
                if (existingAudio) {
                    existingAudio.pause();
                    existingAudio.remove();
                }
                const audio = document.createElement('audio');
                audio.id = 'preview-audio-bg';
                audio.src = renderable.currentAudio.resolvedPath;
                // Use asset controls for audio attributes
                const attrs = getAudioAssetAttrs(renderable.currentAudio.settings || {});
                Object.entries(attrs).forEach(([k, v]) => audio[k] = v);
                audio.style.display = 'none';
                document.body.appendChild(audio);
            } else {
                // Remove any previous audio if not needed
                let existingAudio = document.getElementById('preview-audio-bg');
                if (existingAudio) {
                    existingAudio.pause();
                    existingAudio.remove();
                }
            }

            // Remove any manual scroll/overflow styles from sub-containers
            // Only the main preview area uses the smart scrollbar
        } catch (error) {
            console.error('❌ Preview rendering failed:', error);
            this.showPreviewError('Rendering failed: ' + error.message);
        }
    }

    // Render story text with enhanced formatting
    renderStoryText(textBlocks) {
        const storyElement = document.getElementById('preview-story');
        if (!storyElement) return;

        storyElement.innerHTML = '';
        
        if (textBlocks && textBlocks.length > 0) {
            textBlocks.forEach((text, index) => {
                const p = document.createElement('p');
                p.textContent = text;
                p.className = 'preview-text';
                p.style.animationDelay = `${index * 0.1}s`;
                storyElement.appendChild(p);
            });
        } else {
            const empty = document.createElement('p');
            empty.textContent = 'No story text available.';
            empty.className = 'preview-text empty';
            storyElement.appendChild(empty);
        }
    }

    // Render choices with enhanced styling
    renderChoices(choices) {
        const choicesElement = document.getElementById('preview-choices');
        if (!choicesElement) return;

        choicesElement.innerHTML = '';
        const count = choices && choices.length ? choices.length : 0;
        choicesElement.setAttribute('data-choice-count', count);
        choicesElement.classList.remove('align-left', 'align-center');
        if (count >= 3) {
            choicesElement.classList.add('align-left');
        } else {
            choicesElement.classList.add('align-center');
        }
        // Accessibility: role=list
        choicesElement.setAttribute('role', 'list');
        
        if (choices && choices.length > 0) {
            choices.forEach((choice, index) => {
                const button = document.createElement('button');
                button.textContent = choice.text;
                button.className = 'preview-choice';
                button.onclick = () => this.makeChoice(index);
                button.style.animationDelay = `${index * 0.1}s`;
                // Accessibility: role, tabindex, aria-label
                button.setAttribute('role', 'button');
                button.setAttribute('tabindex', '0');
                button.setAttribute('aria-label', choice.text);
                choicesElement.appendChild(button);
            });
        } else {
            const empty = document.createElement('p');
            empty.textContent = 'No choices available.';
            empty.className = 'preview-text empty';
            choicesElement.appendChild(empty);
        }
    }

    // Render stats with enhanced display
    renderStats(stats) {
        const statsElement = document.querySelector('#preview-stats .panel-content');
        if (!statsElement) return;

        statsElement.innerHTML = '';
        
        if (stats && Object.keys(stats).length > 0) {
            Object.entries(stats).forEach(([key, value]) => {
                const stat = document.createElement('div');
                stat.className = 'preview-stat';
                stat.innerHTML = `
                    <span class="stat-name">${key}:</span> 
                    <span class="stat-value">${value}</span>
                `;
                statsElement.appendChild(stat);
            });
        } else {
            const empty = document.createElement('p');
            empty.textContent = 'No stats available.';
            empty.className = 'preview-empty';
            statsElement.appendChild(empty);
        }
    }

    // Render inventory with enhanced display
    renderInventory(inventory) {
        const inventoryElement = document.querySelector('#preview-inventory .panel-content');
        if (!inventoryElement) return;

        inventoryElement.innerHTML = '';
        
        if (inventory && Object.keys(inventory).length > 0) {
            Object.entries(inventory).forEach(([item, quantity]) => {
                const itemElement = document.createElement('div');
                itemElement.className = 'preview-item';
                itemElement.innerHTML = `
                    <span class="item-name">${item}:</span> 
                    <span class="item-quantity">${quantity}</span>
                `;
                inventoryElement.appendChild(itemElement);
            });
        } else {
            const empty = document.createElement('p');
            empty.textContent = 'No inventory items.';
            empty.className = 'preview-empty';
            inventoryElement.appendChild(empty);
        }
    }

    // Render variables
    renderVariables(vars) {
        const varsElement = document.querySelector('#preview-variables .panel-content');
        if (!varsElement) return;

        varsElement.innerHTML = '';
        
        if (vars && Object.keys(vars).length > 0) {
            Object.entries(vars).forEach(([key, value]) => {
                const varElement = document.createElement('div');
                varElement.className = 'preview-var';
                varElement.innerHTML = `
                    <span class="var-name">${key}:</span> 
                    <span class="var-value">${value}</span>
                `;
                varsElement.appendChild(varElement);
            });
        } else {
            const empty = document.createElement('p');
            empty.textContent = 'No variables defined.';
            empty.className = 'preview-empty';
            varsElement.appendChild(empty);
        }
    }

    // Render log entries
    renderLog(log) {
        const logElement = document.querySelector('#preview-log .panel-content');
        if (!logElement) return;

        logElement.innerHTML = '';
        
        if (log && log.length > 0) {
            // Show last 10 log entries
            const recentLogs = log.slice(-10);
            recentLogs.forEach(entry => {
                const logEntry = document.createElement('div');
                logEntry.className = 'preview-log-entry';
                
                let logText = '';
                if (entry.type === 'choice') {
                    logText = `Choice: ${entry.text}`;
                } else if (entry.type === 'log') {
                    logText = entry.message;
                } else if (entry.type === 'achievement') {
                    logText = `Achievement: ${entry.name}`;
                } else if (entry.type === 'event') {
                    logText = `Event: ${entry.name}`;
                } else {
                    logText = JSON.stringify(entry);
                }
                
                logEntry.textContent = logText;
                logElement.appendChild(logEntry);
            });
        } else {
            const empty = document.createElement('p');
            empty.textContent = 'No log entries.';
            empty.className = 'preview-empty';
            logElement.appendChild(empty);
        }
    }

    // Make a choice in the preview
    makeChoice(index) {
        if (!this.ui) return;

        try {
            // Save current state to history
            this.saveToHistory();
            
            this.ui.choose(index);
            this.renderPreview();
            
            // Update progress
            this.previewState.choicesMade++;
            this.updatePreviewProgress();
            
            logger.info(`✅ Choice ${index} made in preview`);
        } catch (error) {
            logger.error('❌ Choice failed:', error);
            this.showPreviewError('Choice failed: ' + error.message);
        }
    }

    // Step through the preview
    stepPreview() {
        if (!this.ui) return;

        try {
            this.ui.advance();
            this.renderPreview();
            logger.info('✅ Preview stepped');
        } catch (error) {
            logger.error('❌ Step failed:', error);
            this.showPreviewError('Step failed: ' + error.message);
        }
    }

    // Start preview (play mode)
    startPreview() {
        this.previewState.isPlaying = true;
        this.updatePreviewControls();
        this.updatePreviewStatus('Playing', 'success');
    }

    // Pause preview
    pausePreview() {
        this.previewState.isPlaying = false;
        this.updatePreviewControls();
        this.updatePreviewStatus('Paused', 'warning');
    }

    // Restart the preview
    restartPreview() {
        if (!this.ui) return;

        try {
            this.ui.reset();
            this.renderPreview();
            
            // Clear history
            this.history = [];
            this.previewState.choicesMade = 0;
            this.updatePreviewProgress();
            this.updateHistoryControls();
            
            logger.info('✅ Preview restarted');
        } catch (error) {
            logger.error('❌ Restart failed:', error);
            this.showPreviewError('Restart failed: ' + error.message);
        }
    }

    // Save current state to history
    saveToHistory() {
        if (!this.engine) return;

        const state = this.engine.getState();
        this.history.push({
            sceneId: state.sceneId,
            position: state.position,
            vars: { ...state.vars },
            stats: { ...state.stats },
            inventory: { ...state.inventory },
            timestamp: Date.now()
        });

        // Keep only last N entries
        if (this.history.length > this.maxHistorySize) {
            this.history = this.history.slice(-this.maxHistorySize);
        }

        this.updateHistoryControls();
    }

    // Go back in history
    goBackInHistory() {
        if (this.history.length === 0) return;

        const previousState = this.history.pop();
        // TODO: Implement state restoration
        this.updateHistoryControls();
    }

    // Go forward in history
    goForwardInHistory() {
        // TODO: Implement forward history
        this.updateHistoryControls();
    }

    // Update preview controls visibility
    updatePreviewControls() {
        const playBtn = document.getElementById('preview-play');
        const pauseBtn = document.getElementById('preview-pause');

        if (playBtn && pauseBtn) {
            if (this.previewState.isPlaying) {
                playBtn.style.display = 'none';
                pauseBtn.style.display = 'inline-flex';
            } else {
                playBtn.style.display = 'inline-flex';
                pauseBtn.style.display = 'none';
            }
        }
    }

    // Update preview status
    updatePreviewStatus(status, type = 'info') {
        const statusElement = document.getElementById('preview-status');
        if (statusElement) {
            statusElement.textContent = status;
            statusElement.className = `status-indicator ${type}`;
        }
    }

    // Update preview progress
    updatePreviewProgress() {
        const progressElement = document.getElementById('preview-progress');
        if (progressElement) {
            const progress = this.previewState.totalChoices > 0 
                ? Math.round((this.previewState.choicesMade / this.previewState.totalChoices) * 100)
                : 0;
            progressElement.textContent = `${progress}%`;
        }
    }

    // Update history controls
    updateHistoryControls() {
        const backBtn = document.getElementById('preview-history-back');
        const forwardBtn = document.getElementById('preview-history-forward');

        if (backBtn) {
            backBtn.disabled = this.history.length === 0;
        }

        if (forwardBtn) {
            forwardBtn.disabled = true; // TODO: Implement forward history
        }
    }

    // Update scene info
    updateSceneInfo() {
        const sceneElement = document.getElementById('preview-scene');
        const positionElement = document.getElementById('preview-position');

        if (sceneElement && this.engine) {
            sceneElement.textContent = `Scene: ${this.engine.state.sceneId || 'None'}`;
        }

        if (positionElement && this.engine) {
            positionElement.textContent = `Position: ${this.engine.state.position || 0}`;
        }
    }

    // Toggle fullscreen
    toggleFullscreen() {
        const previewFrame = document.getElementById('preview-frame');
        if (!previewFrame) return;

        if (!document.fullscreenElement) {
            previewFrame.requestFullscreen();
        } else {
            document.exitFullscreen();
        }
    }

    // Show preview error
    showPreviewError(message) {
        const storyElement = document.getElementById('preview-story');
        if (storyElement) {
            storyElement.innerHTML = `<p class="preview-error">❌ ${message}</p>`;
        }
    }

    // Stop the preview system
    stop() {
        this.isActive = false;
        if (this.updateTimeout) {
            clearTimeout(this.updateTimeout);
        }
        logger.info('🛑 Enhanced Live Preview System stopped');
    }
}

// Export for use in IDE
// LivePreview is already exported at the class declaration 